import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                ContentView()
            }
        }
    }
}

struct ContentView: View {
    @State private var counter3 = 0
    @State private var counter2 = 0
    @State private var counter = 0
    
    var body: some View {
        Text("\(counter3) : \(counter2) : \(counter)")
            .font(.largeTitle)
            .onAppear {
                Timer.scheduledTimer(withTimeInterval: 1.0 * 60, repeats: true) { timer in
                    if counter3 < 60 {
                        self.counter3 += 1
                    } else {
                        counter3 = 0
                    }
                    
                }
            }
            .onAppear {
                Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
                    if counter2 < 60 {
                        self.counter2 += 1
                    } else {
                        counter2 = 0
                    }
                    
                }
            }
            .onAppear {
                Timer.scheduledTimer(withTimeInterval: 1.0 / 60, repeats: true) { timer in
                    if counter < 60 {
                        self.counter += 1
                    } else {
                        counter = 0
                    }
                    
                }
            }
    }
}















